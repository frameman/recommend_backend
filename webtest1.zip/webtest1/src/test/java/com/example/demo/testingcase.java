package com.example.demo;

import com.example.demo.sql.userdb;
import com.example.demo.sql.userdb.users_detail;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.annotation.Rollback;
import org.junit.*;
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Rollback(value = false)
public class testingcase {
    @Autowired
    private TestEntityManager entityManager;
    @Autowired
    private userdb.UserRepository repo;

    @Test
    public void testCreate(){
        //users_detail user = new users_detail();
        //user.setEmail("abc@a.com");
        //user.setFull_name("Chanlong");
       // users_detail savedUser =repo.save(user);

    }
}
