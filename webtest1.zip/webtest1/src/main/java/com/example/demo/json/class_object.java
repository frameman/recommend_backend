package com.example.demo.json;


import lombok.Builder;
import lombok.Data;
import lombok.extern.jackson.Jacksonized;


public class class_object {

    @Data
    @Builder
    @Jacksonized
    public static class cources {
        public String column;
        public float num;
        public String name;
        //   public String teacher;
        // public String group;
        // public Integer ranking;
    }



   // @GetMapping("test3")
   // public String card() throws Exception {

        //cources card1 = new cources("科學","a","通識",4);
        //System.out.print(card1);

        //ObjectMapper object = new ObjectMapper();

        //String data = object.writeValueAsString(card1); // change class to json
        //System.out.printf(data);

        //cources card2 = object.readValue(data,cources.class);




   // }
    }

