package com.example.demo.ProjectionConfigureation;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.client.*;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.DefaultOAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.web.OAuth2AuthorizedClientRepository;
import org.springframework.security.oauth2.core.OAuth2AccessToken;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestTemplate;


//@Configuration
//public class project {
//    @Bean
//    protected void configure(HttpSecurity http) throws Exception {
//        http.oauth2Client();
//        http.authorizeRequests()
//                .anyRequest().permitAll();
//    }
//
//    @Bean
//    public RestTemplate restTemplate() {
//        return new RestTemplate();
//    }
//
//    @Bean
//    public OAuth2AuthorizedClientManager authorizedClientManager(
//            ClientRegistrationRepository clientRegistrationRepository,
//            OAuth2AuthorizedClientRepository authorizedClientRepository) {
//
//        OAuth2AuthorizedClientProvider authorizedClientProvider =
//                OAuth2AuthorizedClientProviderBuilder.builder()
//                        .clientCredentials()
//                        .build();
//
//        var authorizedClientManager = new DefaultOAuth2AuthorizedClientManager(
//                clientRegistrationRepository,
//                authorizedClientRepository);
//
//        authorizedClientManager
//                .setAuthorizedClientProvider(authorizedClientProvider);
//
//        return authorizedClientManager;
//    }
//    public class TokenManager {
//
//        @Value("${client.registration.name}")
//        private String clientRegistrationName;
//
//        @Value("${spring.security.oauth2.client.registration.app.client-id}")
//        private String clientId;
//
//        private final OAuth2AuthorizedClientManager authorizedClientManager;
//
//        public TokenManager(
//                OAuth2AuthorizedClientManager authorizedClientManager) {
//            this.authorizedClientManager = authorizedClientManager;
//        }
//        public String getAccessToken() {
//            OAuth2AuthorizeRequest authorizeRequest =
//                    OAuth2AuthorizeRequest
//                            .withClientRegistrationId(clientRegistrationName)
//                            .principal(clientId)
//                            .build();
//
//            OAuth2AuthorizedClient authorizedClient =
//                    this.authorizedClientManager
//                            .authorize(authorizeRequest);
//
//            OAuth2AccessToken accessToken = authorizedClient.getAccessToken();
//
//            return accessToken.getTokenValue();
//        }
//    }
//    @Component
//    public class ResourceServerProxy {
//
//        public static final String AUTHORIZATION = "Authorization";
//
//        @Value("${resource.server.url}")
//        private String resourceServerURL;
//
//        private final TokenManager tokenManager;
//
//        private final RestTemplate restTemplate;
//
//        public ResourceServerProxy(
//                TokenManager tokenManager,
//                RestTemplate restTemplate) {
//
//            this.tokenManager = tokenManager;
//            this.restTemplate = restTemplate;
//        }
//
//
//        public String callDemo() {
//            String token = tokenManager.getAccessToken();
//
//            String url = resourceServerURL + "/recommand";
//
//            HttpHeaders headers = new HttpHeaders();
//            headers.add(AUTHORIZATION, "Bearer " + token);
//            HttpEntity<Void> request = new HttpEntity<>(headers);
//
//            var response =
//                    restTemplate.exchange(url, HttpMethod.GET, request, String.class);
//
//            return response.getBody();
//        }
//    }
//
//    public class TestController {
//
//        private final ResourceServerProxy proxy;
//
//        public TestController(ResourceServerProxy proxy) {
//            this.proxy = proxy;
//        }
//
//        @GetMapping("/index")
//        public String test() {
//            return proxy.callDemo();
//        }
//    }
//
//}




