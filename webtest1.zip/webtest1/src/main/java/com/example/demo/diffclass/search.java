package com.example.demo.diffclass;

import lombok.Builder;
import lombok.Data;
import lombok.extern.jackson.Jacksonized;

public class search {
    @Data
    @Builder
    @Jacksonized
    public static class search_d{
        public static String course_name;
        public static String teacher;
        public static int course_num;
    }
}
