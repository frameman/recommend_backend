package com.example.demo.sql;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;


public class  userdb {
    @Builder
    @AllArgsConstructor
    @Entity
    @Table(name = "userinfo")
    public @Data static class users_detail {
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private long id;

        @Column(nullable = false, unique = true, length = 45)
        private String email;
        //@Column(nullable = false,length = 64)
        //  private String password;   //not for now because we are using google account to login

        @Column(nullable = false, name = "full_name", length = 30)
        private String full_name;

        @Enumerated(EnumType.STRING)
        private Provider provider;


        public users_detail() {

        }
    }
     public enum Provider{
        GOOGLE,FACEBOOK
     }


@Service
    public static class UserService{
        @Autowired
        private static UserRepository repo;

    public static void processOAuthPostLogin(String email, String name) {
        users_detail existuser = repo.findByfull_Name(name) ;
         if (existuser == null) {
                  users_detail addUser = new users_detail();
                  addUser.setFull_name(name);
                  addUser.setEmail(email);
                  addUser.setProvider(Provider.GOOGLE);
              repo.save(addUser);
              }
            }


        }
@Repository
    public interface UserRepository extends CrudRepository<users_detail, Long> {
      public users_detail findBy(String name);
    }
}




