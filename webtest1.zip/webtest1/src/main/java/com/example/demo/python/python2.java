package com.example.demo.python;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

@RestController
@RequestMapping("/")
public class python2 {
    @GetMapping("test2")
//    public String Testing() throws IOException{ //fail
//   try{
//    String a = "python Hello_World.py";
//    System.out.print(a);
//    Runtime ru = Runtime.getRuntime();
//    Process proc = ru.exec("Hello_World.py");
//    return("Success");
//   } catch (IOException e) {
//       throw new RuntimeException(e);
//   }
//}

public String re() throws IOException{
       ProcessBuilder pd = new ProcessBuilder("python","Hello_World.py");
       pd.directory(new File("C:\\Users\\tom12\\OneDrive\\Desktop\\java"));
       Process p = pd.start();
       BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
       String line = "";
       String output ="";
       while ((line = reader.readLine()) != null) {
           output = output+line;
           System.out.print(line);
        }
    return (output);



    }
    }




