package com.example.demo.diffclass;

import lombok.Builder;
import lombok.Data;
import lombok.extern.jackson.Jacksonized;

public class CourseRecommendContent {
    @Data
    @Builder
    @Jacksonized
    public static class C_Recommend{
        public  int id;
        public  int course_num;
        public  String teacher;
        public  String course_name;
        public  String rating;
        public  String field;
    }

    }

