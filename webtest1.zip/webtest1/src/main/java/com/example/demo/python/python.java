package com.example.demo.python;
import java.io.File;
import java.io.IOException;



public class python {
public String re() throws IOException{
       ProcessBuilder pd = new ProcessBuilder("python","general_recommend.py");
       pd.directory(new File("src/main/java/com/example/demo/python/recommend-system-main/_General_courses"));
       Process p = pd.start();
      // BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
       //String line = "";
      // String output ="";
       //while ((line = reader.readLine()) != null) {
        //   output = output+line;
        //   System.out.print(line);
        //}
return null;
    }
}




