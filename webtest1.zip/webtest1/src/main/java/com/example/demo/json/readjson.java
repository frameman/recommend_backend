package com.example.demo.json;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.jackson.Jacksonized;
import org.apache.catalina.mapper.Mapper;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.io.File;
import java.lang.runtime.ObjectMethods;
import java.nio.file.Files;
import java.nio.file.Paths;
@RestController

public class readjson {
    @GetMapping("/json")
    public String a() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        class_object.cources a = mapper.readValue(new File("C:\\Users\\tom12\\OneDrive\\Desktop\\recommend-system-main\\data.json"), class_object.cources.class);
        System.out.print(a.name);
        return ("abc");
    }


    }


