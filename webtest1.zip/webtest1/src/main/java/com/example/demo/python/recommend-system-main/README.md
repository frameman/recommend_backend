# recommend-system
參考: https://www.youtube.com/watch?v=ijtxuF_5kEU 
      https://zhuanlan.zhihu.com/p/68373487
      https://github.com/ugis22/music_recommender
