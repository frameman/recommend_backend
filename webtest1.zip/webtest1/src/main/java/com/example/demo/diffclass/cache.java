package com.example.demo.diffclass;

import lombok.Builder;
import lombok.Data;
import lombok.extern.jackson.Jacksonized;

public class cache {
    @Jacksonized
    @Data
    @Builder
    public static class caches{
        public String name;
    }
}
