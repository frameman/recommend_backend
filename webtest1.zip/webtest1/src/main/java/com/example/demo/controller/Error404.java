package com.example.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class Error404 {
        @GetMapping("404")
        public String title(){
            System.out.print("");
            return "404 Error";
        }
    }

