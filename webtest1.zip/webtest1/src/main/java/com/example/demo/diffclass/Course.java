package com.example.demo.diffclass;

import lombok.Builder;
import lombok.Data;
import lombok.extern.jackson.Jacksonized;

public class Course {
    @Data
    @Builder
    @Jacksonized
    public static class Courses{
        public static int id;
        public static String teacher;
        public static String course_name;
        public static int course_num;
    }
}
