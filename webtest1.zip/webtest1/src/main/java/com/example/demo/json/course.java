package com.example.demo.json;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Builder;
import lombok.Data;
import lombok.extern.jackson.Jacksonized;
import org.springframework.web.bind.annotation.GetMapping;

import java.nio.file.Files;
import java.nio.file.Paths;

public class course {
    @Data
    @Builder
    @Jacksonized
    public static class courseA{
        public String name;
        public float similarity;
    }
    @JsonProperty
    @GetMapping("test4")
    public String a() throws Exception {
        String file = "C:\\Users\\tom12\\OneDrive\\Desktop\\recommend-system-main\\data.json";
        String json = readFileAsString(file);


        return ("abc");
    }
    private String readFileAsString(String file) throws Exception {
        return new String(Files.readAllBytes(Paths.get(file)));
    }

}
